import styled from "styled-components"


export default styled.div`
display:flex;
justify-content:center;
align-item:center;
height:250px;
width:100%;
color:#fff;
background-color:#00008B;
margin :0 15px;

`;
