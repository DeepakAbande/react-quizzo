import React from 'react'

function Email_ver() {
  return (
    <div className='Container'>
    <div className='head'>
      <h3>Email Verification</h3>
      
      <p>An email has been sent to your registerd email Id to verify your account</p>
    </div>
    <div className='btn_div'>
    <button className="btn"type="submit">Ok</button>
    </div>
    </div>
  )
}

export default Email_ver;